(function ($) {
    "use strict"; // Start of use strict
    /* CUSTOM VARIATIONS */

})(jQuery); // End of use strict